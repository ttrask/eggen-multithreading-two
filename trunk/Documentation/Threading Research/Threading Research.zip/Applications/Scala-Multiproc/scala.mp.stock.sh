scala -J-Xmx4g  stock.Stock -n 10000 
