export CLASSPATH=~/Scala-Multiproc/bin

cd ~/Scala-Multiproc/bin/multicore
scala multicore.Multicore
