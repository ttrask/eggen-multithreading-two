
scala -J-Xmx6g  client.ClientShell -s 1 -n 1000 
