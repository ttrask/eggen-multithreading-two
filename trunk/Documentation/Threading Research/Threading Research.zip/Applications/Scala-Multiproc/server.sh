cd ~/MP/Scala-Multiproc/bin/server
scala server.ServerShell -name $1
