
scala -J-Xmx4g  multicore.Multicore -t 2 -n 100