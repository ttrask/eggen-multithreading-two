export GOPATH=~/MP/Go-Multiproc/

