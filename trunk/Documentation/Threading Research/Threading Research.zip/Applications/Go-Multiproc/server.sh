export GOPATH=~/MP/Go-Multiproc/

go run ~/MP/Go-Multiproc/src/server/server.go :1602 