export GOPATH=~/MP/Go-Multiproc/
go run ~/MP/Go-Multiproc/src/Client/client.go -s 1 -n 100 -clf clients.txt 